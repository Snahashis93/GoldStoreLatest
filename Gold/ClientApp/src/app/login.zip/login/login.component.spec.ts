import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { LoginComponent } from "./login.component";
import { FormsModule } from "@angular/forms";
import { UserService } from "src/app/json.service";
import { EMPTY, Observable, of, throwError } from "rxjs";

import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { NO_ERRORS_SCHEMA, Injectable } from "@angular/core";
@Injectable()
class MockedClass {
  login() {
    const x = { isPrivileged: true };
    return x;
  }
}
describe("LoginComponent", () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let service;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      providers: [{ provide: UserService, useClass: MockedClass }],
      imports: [FormsModule, HttpClientTestingModule, RouterTestingModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    service = TestBed.get(UserService);
    //spyOn(service, "login").and.returnValue("");
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should call login() ", () => {
    const todos = [
      { id: 1, title: "a" },
      { id: 2, title: "b" },
      { id: 3, title: "c" },
    ];
    const x = { isPrivileged: true };
    spyOn(service, "login").and.returnValue(of(x));
    component.login();
    expect(service.login).toHaveBeenCalled();
  });
  it("should call login() failure ", () => {
    const todos = [
      { id: 1, title: "a" },
      { id: 2, title: "b" },
      { id: 3, title: "c" },
    ];
    const x = { isPrivileged: true };
    spyOn(service, "login").and.returnValue(
      throwError({ status: 404, error: "nn" })
    );
    component.login();
    expect(service.login).toHaveBeenCalled();
  });
});
